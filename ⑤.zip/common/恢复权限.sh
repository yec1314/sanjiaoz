#之前网传的解决设备标记模块，用MT新建脚本执行即可。重启失效



#!/system/bin/sh

# 设置目标目录
TARGET_DIR="/mnt/vendor/persist/data"

# 检查目录是否存在
if [ -d "$TARGET_DIR" ]; then
    # 仅设置目录本身的权限为000（---）
    chmod 755 "$TARGET_DIR"
    echo "权限修改成功"
else
    echo "错误 $TARGET_DIR"
fi  